package com.firebase.appauthfirebase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.OptionalPendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.GoogleApiAvailabilityCache;

public class MainActivity extends AppCompatActivity implements GoogleApiClient.OnConnectionFailedListener {
    private ImageView imageView;
    private TextView txtN, txtCor, txtCod;

    //agregar la clase de googleapiclient

    GoogleApiClient googleApiClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView = findViewById(R.id.imageView);
        txtN = findViewById(R.id.txtNombre);
        txtCor = findViewById(R.id.txtCorreo);
        txtCod = findViewById(R.id.txtCodigo);

        GoogleSignInOptions googleSignInOptions = new GoogleSignInOptions.Builder
                (GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().build();

        googleApiClient = new GoogleApiClient.Builder(this).enableAutoManage(this,this)
                .addApi(Auth.GOOGLE_SIGN_IN_API,googleSignInOptions).build();
    }

    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btnLogout:
                Auth.GoogleSignInApi.signOut(googleApiClient).setResultCallback(new ResultCallback<Status>() {
                    @Override
                    public void onResult(@NonNull Status status) {
                        if(status.isSuccess()){
                            irLogIn();
                        }
                        else{
                            Toast.makeText(MainActivity.this, "No es posible cerrar sesion", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                break;
            case R.id.btnRevoke:
                Auth.GoogleSignInApi.revokeAccess(googleApiClient).setResultCallback(new ResultCallback<Status>() {
                    @Override
                    public void onResult(@NonNull Status status) {
                        if(status.isSuccess()){
                            irLogIn();
                        }else{
                            Toast.makeText(MainActivity.this, "No se puede revocar sesion", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                break;
            default:

                break;

        }
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    protected void onStart() {
        super.onStart();
        OptionalPendingResult<GoogleSignInResult> optionalPendingResult = Auth.GoogleSignInApi.silentSignIn(googleApiClient);

        if(optionalPendingResult.isDone()){
            GoogleSignInResult googleSignInResult = optionalPendingResult.get();
            obtenerResultado(googleSignInResult);
        }
        else{
            optionalPendingResult.setResultCallback(new ResultCallback<GoogleSignInResult>() {
                @Override
                public void onResult(@NonNull GoogleSignInResult googleSignInResult) {
                    obtenerResultado(googleSignInResult);
                }
            });
        }
    }

    private void obtenerResultado(GoogleSignInResult googleSignInResult) {
        if(googleSignInResult.isSuccess()){
            GoogleSignInAccount googleSignInAccount = googleSignInResult.getSignInAccount();
            txtN.setText(googleSignInAccount.getDisplayName());
            txtCor.setText(googleSignInAccount.getEmail());
            txtCod.setText(googleSignInAccount.getId());
            Glide.with(this).load(googleSignInAccount.getPhotoUrl()).into(imageView);
        }else{

            irLogIn();
        }
    }

    private void irLogIn(){
        Intent intent = new Intent(getApplicationContext(),LogIn.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

}
